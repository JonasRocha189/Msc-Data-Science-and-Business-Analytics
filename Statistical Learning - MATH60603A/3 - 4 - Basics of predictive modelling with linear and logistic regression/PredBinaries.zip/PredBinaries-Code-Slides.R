# The code herein was used to produce the plots and numbers in Theme 4.
# There are three different sources of data.
# They are used in turn.

require(tidyverse)

###
# Plot of the logit link

x=(-40:40)/10
plot(x,exp(x)/(1+exp(x)),type="l",xlab="x",ylab="Inverse logit",ylim=0:1,col="red",lwd=2)

###
# Home equity data
# This data set is from SAS
# A copy of the dataset is available on ZoneCOurs

data=read.csv("HMEQ.csv",sep=";")
str(data)

# Creating a hold-out validation set
set.seed(60603)
keep=sample(1:nrow(data))
train=data[keep[2001:nrow(data)],]
valid=data[keep[1:2000],]

# There are missing values for this set.
apply(is.na(train),2,sum)
apply(is.na(valid),2,sum)


# This dataset contains missing values on some numerical variables. 
# We will discuss later how to handle missing values, but let's use single imputation 
# where all missing values of a variable are replaced with the mean of the non missing values.
# We will also create new variables to keep track of those values who were missing -- this can 
# sometimes be very predictive itself.

imputation_mean=sapply(train,mean,na.rm=TRUE)

# Warnings come from trying to compute the mean of a factor. 
# It gives NA as an output. We can ignore these warnings here.

trainimp=train %>% 
  mutate(MISS_MORTDUE=is.na(MORTDUE),MISS_VALUE=is.na(VALUE),MISS_YOJ=is.na(YOJ),MISS_DEROG=is.na(DEROG),
         MISS_DELINQ=is.na(DELINQ),MISS_CLAGE=is.na(CLAGE),MISS_NINQ=is.na(NINQ),MISS_CLNO=is.na(CLNO),
         MISS_DEBTINC=is.na(DEBTINC))
validimp=valid %>% 
  mutate(MISS_MORTDUE=is.na(MORTDUE),MISS_VALUE=is.na(VALUE),MISS_YOJ=is.na(YOJ),MISS_DEROG=is.na(DEROG),
         MISS_DELINQ=is.na(DELINQ),MISS_CLAGE=is.na(CLAGE),MISS_NINQ=is.na(NINQ),MISS_CLNO=is.na(CLNO),
         MISS_DEBTINC=is.na(DEBTINC))

for(i in c(1:3,6:12)){
  trainimp[[i]][is.na(trainimp[[i]])]=imputation_mean[i]
  validimp[[i]][is.na(validimp[[i]])]=imputation_mean[i]
}

######
# Showing predictions are probabilities
# full model and its predictions to get started
a1=glm(PAID~.-ID,data=trainimp[,1:14],family="binomial")
summary(a1)
p1=predict(a1,newdata=validimp,type="response")
a=cbind(ID=validimp$ID,Prob_Pay=p1)[sort.list(p1,decreasing=TRUE)[1:20],]

a2=glm(PAID~.-ID,data=trainimp,family="binomial")
summary(a2)
p2=predict(a2,newdata=validimp,type="response")
a=cbind(ID=validimp$ID,Prob_Pay=p2)[sort.list(p2,decreasing=TRUE)[1:20],]

# In general, it may be better to first look for packages that do the analyses
# In many cases, here, we provide a custom made function to make those calculations.
# Those functions have been placed in a separate file

source("Theme4-functions.R")

# Computing the confusion matrix and some performance statistics

confusion(validimp$PAID,as.numeric(p1>.5))
confusion(validimp$PAID,as.numeric(p1>.9))

confusion(validimp$PAID,as.numeric(p2>.5))
confusion(validimp$PAID,as.numeric(p2>.9))

# Plotting the ROC curve

roc(validimp$PAID,p1,col="blue")$AUC
roc(validimp$PAID,p2,lines=TRUE,col="red")$AUC


# Plotting the lift chart

lift(validimp$PAID,p2,col="red")
lift(validimp$PAID,p1,lines=TRUE,col="blue")

# Lift for predicting bad payers

lift(1-validimp$PAID,1-p2,col="red")
lift(1-validimp$PAID,1-p1,lines=TRUE,col="blue")

# Considering the cost of errors
# No loan = no risk
# Good loan = -1 (a gain)
# Loan to bad payer = 10 (a loss)

par(mfrow=c(1,2))
cost(validimp$PAID,p1,col="blue")$ThresholdMin
cost(validimp$PAID,p2,col="red")$ThresholdMin

# In a real life situation, it may be better to look for existing functions rather than redifining them every time.
# The ROCR package has functions for the ROC curve, other plots as well as numerous performance metrics.

library(ROCR)

# Plotting the ROC curve
pred=prediction(p1,validimp$PAID)
perf=performance(pred,"tpr","fpr")
plot(perf)

# For reference, plotting the same curve with the custom function
roc(validimp$PAID,p1,lines=TRUE,col="red")$AUC

# perf is a S4 object, not a list. 
# We can look into its content with commands such as:
slotNames(perf)
perf@x.name

# Computing the AUC
performance(pred,"auc")

# The ROCR package seems to consider all possible points where the threshold has an impact (each value of p)
# The custom function takes only k values instead to get a good approximation.
# As a result, the plots as well as the AUC are not precisely identical.

# Liftchart
liftchart=performance(pred,measure="lift", x.measure="rpp")
plot(liftchart)

# For reference, plotting the same curve with the custom function
lift(validimp$PAID,p1,lines=TRUE,col="red")

# Unfortunately, the ROCR lift chart starts at (0,0), which does not make much sense.
# The idea of the lift is to look at the ratio of how many people are 1s with a model vs at random.
# If we invite nobody, both those numbers are 0, so it would make more sense to consider the lift undefined at 0.
# Starting the plot at 0 does not allow to see the details as well.

# Considering costs
# The ROCR function allows only to give costs of false positives and false negatives
# False positive: we give a loan to somebody who does not pay : cost=10
# False negative: we decline a loan to a good payer: cost=1 (in loss profit)
# The previous matrix of cost allows to think directly of the consequence of each possible outcome
# When only looking anf FP and FN, one has to to think of the unrealised sales too.
costsol=performance(pred,measure="cost", cost.fp=10,cost.fn=1)

plot(costsol)

# Optimal cutoff -- x scale on threshold rather than depth
slotNames(costsol)
costsol@x.values[[1]][which.min(costsol@y.values[[1]])]

