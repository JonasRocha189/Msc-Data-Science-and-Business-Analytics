# The code herein was used to produce the plots and numbers in Theme 3.
# There are three different sources of data.
# They are used in turn.

require(ggplot2)
require(tidyverse)

###
# Diamonds example
# This data set is shipped with the ggplot2 library

data(diamonds)

# Adding carat^2 now for future use

data=diamonds %>%
  filter(clarity=="VS2" & color=="I") %>%
  mutate(carat2=carat^2)
  
# Creating a hold-out validation set
# Not all data are used -- this is very unusual, you would normally keep alll
# When I initially prepared the slides, I chose round number to make the example easier to follow.

set.seed(1620)
keep=sample(1:dim(data)[1],700)
train=data[keep[1:500],]
valid=data[keep[501:700],]

# Looking at the data type
str(train)
head(train)

# 3 first simple models and their predictions
a1=lm(price~carat,data=train)
summary(a1)
predict(a1,data.frame(carat=1.33))

a2=lm(price~carat+cut,data=train)
summary(a2)
predict(a2,data.frame(carat=1.33,cut="Very Good"))

a3=lm(price~carat+cut+x+y+z,data=train)
summary(a3)
predict(a3,data.frame(carat=1.33,cut="Very Good",x=6.99,y=7.02,z=4.38))

# This function will be used to compute the RMSEon all models
# The advantage of creating a function is that we can use an apply statement
# to evaluate all the models we chose so far and kept in a list

RMSE=function(mod){
  p=predict(mod,valid)
  c(nvar=mod$rank-1,RMSE=sqrt(mean((p-valid$price)^2)))
}

models=list(Carat=a1,CaratCut=a2,Allvars=a3)
t(sapply(models,RMSE))

# Plot of Price vs carat that shows a lack of linearity
# When making predictions, we typically do not care much about the 
# assumptions of the linear regression model, except when they
# help us find better models like here.
plot(train$carat,train$price,pch=20,col="blue",xlab="carat",ylab="Price")
abline(a1,col="red",lwd=2)
title("Price vs carat")

# The leaps library can search the best model, but it uses only the training set.
# One option is to use a penalized statistics such as the BIC, but this is 
# not as good as using the hold-out validation sample.
require(leaps)
a3b=regsubsets(price ~ .,
             data = train,
             nbest = 1,       # 1 best model for each number of predictors
             nvmax = NULL,    # NULL for no limit on number of variables
             force.in = NULL, force.out = NULL,
             method = "exhaustive")

plot(summary(a3b)$bic,xlab="Best model with __ variables",ylab="BIC")
summary(a3b)

a3c=lm(price~x+y+carat2,data=train)

# We also add carat^2 to all the previously consired models  
a4=lm(price~carat+carat2,data=train)
summary(a4)
predict(a4,data.frame(carat=1.33,carat2=1.33^2))

a5=lm(price~carat+carat2+cut,data=train)
summary(a5)
predict(a5,data.frame(carat=1.33,carat2=1.33^2,cut="Very Good"))

a6=lm(price~carat+carat2+cut+x+y+z,data=train)
summary(a6)
predict(a6,data.frame(carat=1.33,carat2=1.33^2,cut="Very Good",x=6.99,y=7.02,z=4.38))

# The step function proceeds with a stepwise algorithm based on AIC 
a7=step(a6)

models=c(models,list(CaratCarat2=a4,CaratCarat2Cut=a5,AllvarswithCarat2=a6,Leaps=a3c,StepAIC=a7))
t(sapply(models,RMSE))



####
# White wine
# This dataset comes from the UCI Machine Learning repository
# You may find it from here: https://archive.ics.uci.edu/ml/machine-learning-databases/wine-quality/

wine=read.csv("winequality-white.csv",sep=";")
str(wine)

# Again, very unusual to dismiss data, unless the sample size was huge, which it is not here. 
set.seed(60603)
ord=sample(1:nrow(wine))
trainw=wine[ord[1:1500],]
validw=wine[ord[1501:3000],]
testw=wine[ord[3801:4800],]

RMSEw=function(mod){
  p=predict(mod,validw)
  c(nvar=mod$rank-1,RMSE=sqrt(mean((p-validw$quality)^2)))
}

# Some models are considered, including the complete model and an all-subset search with BIC
w1=lm(quality~alcohol,data=trainw)
w2=lm(quality~alcohol+residual.sugar+fixed.acidity+volatile.acidity,data=trainw)
w3=lm(quality~alcohol+residual.sugar+fixed.acidity+volatile.acidity+pH+sulphates,data=trainw)
w4=lm(quality~.,data=trainw)
w5=step(w4)

findw6=regsubsets(quality ~ .,
               data = trainw,
               nbest = 1,       # 1 best model for each number of predictors
               nvmax = NULL,    # NULL for no limit on number of variables
               force.in = NULL, force.out = NULL,
               method = "exhaustive")

plot(summary(findw6)$bic,xlab="Best model with __ variables",ylab="BIC")

w6=lm(quality~volatile.acidity+residual.sugar+density+sulphates+alcohol,data=trainw)

# It would be much better to choose among all subsets based on the validation RMSE.
# There does not seem to be a package function for that, so let's code it ourselves.
# We need to decide how to fit subsets. One option is to select columns from the data set.
# This is why we first create a matrix than can subset the appropriate columns.
# We then use an apply statement.

keep=function(p){
  mat=matrix(c(FALSE,TRUE),2,1)
  for(i in 1:(p-1)) mat=cbind(rep(c(FALSE,TRUE),each=2^i),rbind(mat,mat))
  mat[-1,]
}

fitRMSE=function(u){
  w=lm(quality~.,data=trainw[,c(TRUE,u)])
  p=predict(w,validw)
  sqrt(mean((p-validw$quality)^2))
}

# We can use
a=apply(keep(11),1,fitRMSE)

# but using an apply statement makes it easy to parallelize (and speed up) the computation
library(parallel)
cl=makeCluster(8)
clusterExport(cl,c("trainw","validw"))
a=parApply(cl,keep(11),1,fitRMSE)

# Just to compare, look a the time difference
system.time(apply(keep(11),1,fitRMSE))
system.time(parApply(cl,keep(11),1,fitRMSE))

# We choose the best model from that list
u=keep(11)[which.min(a),]
w7=lm(quality~.,data=trainw[,c(TRUE,u)])

modelsw=list(alcohol=w1,alcsugaracid=w2,alcsugaracidphsulfates=w3,all=w4,step=w5,allsubset_BIC=w6,allsubset_validRMSE=w7)
t(sapply(modelsw,RMSEw))

# Let's now add all square variables and interaction terms to the model.
# Instead of 11 variables, we will now have 77.
for(i in 2:12){
  for(j in i:12){
    wine = wine %>% mutate(!!paste(names(wine)[[i]],names(wine)[[j]],sep="_"):=wine[[i]]*wine[[j]])
  }
}

trainw=wine[ord[1:1500],]
validw=wine[ord[1501:3000],]
testw=wine[ord[3001:4000],]

# We keep all and try stepwise
# It would be hard to to an all-subset on the holdout RMSE.
# To do so, we would need to fit each model one by one and retain only the best so far.
# The code above cannot even be use. Just the grid used to code which variable
# is in the model is 2^77 by 77 > 2^83. This matrix in memory takes at least
# 2^77 bits = 2^74 bytes = 2^64 KB = 2^54 MB = 2^44 GB. That is way too much!
# To compute it, we need to change the coding to dismiss what is not needed as we go.
# Even then, the memory may be ok, but the computations may be too slow to come along.
w8=lm(quality~.,data=trainw)
w9=step(w8)

modelsw=c(modelsw,list(withinter=w8,stepwithinter=w9))
t(sapply(modelsw,RMSEw))

#Adding a column for RMSE on the test set for reference
RMSEwtest=function(mod){
  p=predict(mod,validw)
  p2=predict(mod,testw)
  c(nvar=mod$rank-1,RMSE=sqrt(mean((p-validw$quality)^2)),RMSEtest=sqrt(mean((p2-testw$quality)^2)))
}
t(sapply(modelsw,RMSEwtest))

# Getting information about the 50 best wines identifies by the models
newine=function(mod){
  p=predict(mod,testw)
  grade=testw$quality[sort.list(p,decreasing=TRUE)[1:50]]
  c(Mean=mean(grade),Piquette=sum(grade<=5),TopQual=sum(grade>=7))
}
t(sapply(modelsw,newine))

# Information for the randomchoice
sum(testw$quality<=5)
sum(testw$quality>=7)
mean(testw$quality)


#######
# Polynomial

# A polynomial regression is simulated to illustrate the importance of
# having enough variables but not too many

# Simulating the data
set.seed(1324657)
x=runif(30,-10,10)
y=x^3-x^2-6*x+200*rnorm(30)

# Plotting the data with the true model
plot(x,y,pch=20,xlim=c(-10,10),ylim=c(-1100,1100),col="blue")
gridx=(0:50)/50*20-10
lines(gridx,gridx^3-gridx^2-6*gridx,col="red",lwd=2)
truef=gridx^3-gridx^2-6*gridx
title("True Model")

# Plotting the model with an increasing number of variables
# Note that saying RMSE here is an abuse of language because we 
# really restimate the square root of the GMSE since we use the 
# true model in the calculation (true curve and uniformity of x).
xx=data.frame(y=y)
gridxx=1
RMSE=NULL
par(mfrow=c(2,2))
for(i in 1:4){
  xx=data.frame(xx,x^i)
  a=lm(y~.,data=xx)
  gridxx=cbind(gridxx,gridx^i)
  plot(x,y,pch=20,xlim=c(-10,10),ylim=c(-1100,1100),col="blue")
  lines(gridx,c(gridxx%*%as.matrix(a$coeff)),col="red",lwd=2)
  title(paste("Polynomial of degree",i) ) 
  RMSE=c(RMSE,sqrt(mean((truef-gridxx%*%as.matrix(a$coeff))^2)))
}

for(i in 5:8){
  xx=data.frame(xx,x^i)
  a=lm(y~.,data=xx)
  gridxx=cbind(gridxx,gridx^i)
  plot(x,y,pch=20,xlim=c(-10,10),ylim=c(-1100,1100),col="blue")
  lines(gridx,c(gridxx%*%as.matrix(a$coeff)),col="red",lwd=2)
  title(paste("Polynomial of degree",i) ) 
  RMSE=c(RMSE,sqrt(mean((truef-gridxx%*%as.matrix(a$coeff))^2)))
}

# The plot shows how the RMSE varies
plot(RMSE,xlab="Number of variable",type='b',col="red",pch=20,lwd=2)
title("Error vs number of variables")
