
# Examples of SVM
# ---------------
# A random data set is plotted. The support vector are circled. They are the
# points that determine the decision boundary. Points are separable by a line.

set.seed(2019)
y=matrix(rnorm(200),ncol=2)+rep(c(0,5),each=50)
lab=rep(c("Red","Blue"),each=50)
plot(y,col=lab,pch=20,xlab="X1",ylab="X2")

b=svm(y,as.factor(lab),kernel="linear")
summary(b)
points(y[b$index,],col=lab[b$index],cex=2)

# To draw the boundaries, use the following line:
boundaries(y,b)


# Example with misclassification
# ------------------------------
# Same thing with data that cannot be separated by a line.

set.seed(2019)
y=matrix(rnorm(200),ncol=2)+rep(c(0,1.8),each=50)
lab=rep(c("Red","Blue"),each=50)

plot(y,col=lab,pch=20,xlab="X1",ylab="X2")
b=svm(y,as.factor(lab),kernel="radial",cost=10000000000)
title("c=10000000000")
boundaries(y,b)

# Example with circles
# --------------------
# Same thing with concentric data.

norm=function(x){sqrt(sum(x^2))}
y=matrix(rnorm(400),ncol=2)
y[1:100,]=y[1:100,]+4*y[1:100,]/apply(y[1:100,],1,norm)
lab=rep(c("Red","Blue"),each=100)
plot(y,col=lab,pch=20)

b=svm(y,as.factor(lab),kernel="linear")
summary(b)
fit=as.character(b$fitted)
points(y[fit!=lab,],col=fit[fit!=lab],pch=5,cex=1.5)

# To draw the boundaries, use the following line:
boundaries(y,b)

# Using a radial kernel will allow to separate the data.
b=svm(y,as.factor(lab),kernel="radial")
summary(b)
fit=as.character(b$fitted)
plot(y,col=lab,pch=20)
points(y[fit!=lab,],col=fit[fit!=lab],pch=5,cex=1.5)

# To draw the boundaries, use the following line:
boundaries(y,b)

# New data are produced and classified.
# Misclassified points are circled.
y2=matrix(rnorm(200),ncol=2)
y2[1:50,]=y2[1:50,]+4*y2[51:100,]/apply(y2[51:100,],1,norm)
lab=rep(c("Red","Blue"),each=50)
b=svm(y2,as.factor(lab),kernel="radial")
fit=as.character(predict(b,y2))
plot(y2,col=lab,pch=20)
points(matrix(y2[fit!=lab,],ncol=2),cex=1.2)

# To draw the boundaries, use the following line:
boundaries(y2,b)


# Example with many clusters
# --------------------------
# In this example, there are 4 groups.

set.seed(20181010)
norm=function(x){sqrt(sum(x^2))}
y=matrix(rnorm(400),ncol=2)
y[51:100,]=y[51:100,]+3*y[51:100,]/apply(y[51:100,],1,norm)
y[101:150,]=y[101:150,]+c(8,8)
y[151:200,]=y[151:200,]+6*y[151:200,]/apply(y[151:200,],1,norm)
lab=rep(c("Red","Blue","Green","Black"),each=50)
par(mfrow=c(1,2))
plot(y,col=lab,pch=20,axes=FALSE,xlab="",ylab="",frame.plot=TRUE)

plot(y,col=lab,pch=20,axes=FALSE,xlab="",ylab="",frame.plot=TRUE)

# 20 points are removed from the data set as a form of validation of the model.

boundaries(y,svm(y,as.factor(lab),kernel="radial"))

chk=sample(1:200,20)
b=svm(y[-chk,],as.factor(lab[-chk]),kernel="radial")
summary(b)
fit=as.character(predict(b,y[chk,]))
plot(y[-chk,],col=lab[-chk],pch=20)

# Draws the points that were removed as crosses with the color matching the
# prediction.
points(y[chk,],col=fit,pch=3)

# Draws a little box on points that are misclassified (if any)
points(matrix(y[chk[fit!=lab[chk]],],ncol=2),col=lab[chk[fit!=lab[chk]]],pch=7)

# To draw the boundaries, use the following line:
boundaries(y,b)
